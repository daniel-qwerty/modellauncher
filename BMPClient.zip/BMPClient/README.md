# BMPClient

[![CI Status](http://img.shields.io/travis/skynet/BMPClient.svg?style=flat)](https://travis-ci.org/skynet/BMPClient)
[![Version](https://img.shields.io/cocoapods/v/BMPClient.svg?style=flat)](http://cocoapods.org/pods/BMPClient)
[![License](https://img.shields.io/cocoapods/l/BMPClient.svg?style=flat)](http://cocoapods.org/pods/BMPClient)
[![Platform](https://img.shields.io/cocoapods/p/BMPClient.svg?style=flat)](http://cocoapods.org/pods/BMPClient)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

BMPClient is available through [CocoaPods](http://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'BMPClient'
```

## Author

skynet, Snooopd00g007.

## License

BMPClient is available under the MIT license. See the LICENSE file for more info.
